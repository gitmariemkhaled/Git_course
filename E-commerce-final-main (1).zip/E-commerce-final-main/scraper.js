import fs from "fs";
import puppeteer from "puppeteer";

(async () => {
  const browser = await puppeteer.launch({ headless: false }); // اجعل المتصفح مرئيًا للاختبار
  const page = await browser.newPage();
  await page.goto("https://www.jumia.com.eg/"); // استبدل بالرابط المناسب

  await page.click('button[aria-label="Accept cookies"]').catch(() => { });
  await page.waitForSelector("article.prd");

  // استخراج المنتجات الأساسية
  const products = await page.evaluate(() => {
    return Array.from(document.querySelectorAll("article.prd")).map((product, index) => {
      const name = product.querySelector(".name")?.innerText.trim();
      const price = product.querySelector(".prc")?.innerText.trim();
      const image = product.querySelector("img")?.getAttribute("data-src");
      const link = product.querySelector("a")?.href;

      if (!name || !price || !image || !link) return null; // تجاهل المنتجات الناقصة

      return { id: index + 1, name, price, image, link };
    }).filter(product => product !== null);
  });

  console.log("جاري استخراج تفاصيل المنتجات...");

  // استخراج التفاصيل الإضافية لكل منتج
  for (let product of products) {
    const productPage = await browser.newPage();
    await productPage.goto(product.link, { waitUntil: "domcontentloaded" });

    // استخراج التفاصيل الإضافية
    const details = await productPage.evaluate(() => {
      const description = document.querySelector(".markup")?.innerText.trim() || "لا يوجد وصف";
      const rating = document.querySelector(".stars")?.innerText.trim() || "غير متوفر";
      const specs = Array.from(document.querySelectorAll(".fea .-pv")).map(el => el.innerText.trim());

      return { description, rating, specs };
    });

    product.details = details;
    await productPage.close();
  }

  fs.writeFileSync("clothes.json", JSON.stringify(products, null, 2));

  console.log("تم استخراج البيانات بنجاح!");
  await browser.close();
})();