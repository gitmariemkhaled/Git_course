import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import { faCartShopping } from "@fortawesome/free-solid-svg-icons";
import { faXmark } from "@fortawesome/free-solid-svg-icons";
import { useContext } from "react";
import { ShopContext } from "./cart/shopContext";
import { FavoritesContext } from "./favorite/favoriteContext";
export const Mobilenav = ({ open, setopen, links }) => {
  const { getTotalCartItems } = useContext(ShopContext);
  const { getTotalFavoriteItems } = useContext(FavoritesContext);
  return (
    <>
      <div
        className={`fixed w-screen backdrop-blur-3xl bg-[#41352D] top-0 z-40 flex flex-col md:hidden items-center justify-center duration-300 ${
          open
            ? "h-screen opacity-100 pointer-events-auto"
            : "h-0 opacity-0 pointer-events-none"
        }`}
      >
        <div className="w-full px-7 mb-5">
          <form className="flex justify-center max-w-2xl m-auto" action="#">
            <label htmlFor="search" className="flex flex-row w-full">
              <FontAwesomeIcon
                icon={faMagnifyingGlass}
                className="text-lg border p-3 rounded-l-lg"
              />
              <input
                id="search"
                type="search"
                className="border w-full rounded-r-lg text-white p-2 outline-0"
                autoComplete="off"
              />
            </label>
          </form>
        </div>
        <button
          className="absolute top-3 right-4"
          onClick={() => setopen(false)}
        >
          <FontAwesomeIcon icon={faXmark} className="text-4xl" />
        </button>
        <ul className="text-center uppercase text-2xl px-7 w-screen flex flex-col items-center">
          {links.map((item) => (
            <Link
              className="border sm:m-5 m-3 p-3 max-w-2xl w-full"
              onClick={() => setopen(false)}
              to={item.link}
            >
              {item.name}
            </Link>
          ))}
        </ul>
        <div className="flex gap-5 justify-around flex-col sm:flex-row w-full mt-3 px-7 max-w-2xl">
          <button
            className=" border w-full py-2"
            onClick={() => setopen(false)}
          >
            <div className="relative">
              <span className="bg-amber-600 rounded-full w-5 h-5 text-center pt-[3px] absolute -top-2 -right-2 text-[10px]">
                {getTotalFavoriteItems()}
              </span>
              <Link to={`/Favorite`}>
                <FontAwesomeIcon icon={faHeart} className="text-2xl" />
              </Link>
            </div>
          </button>

          <button
            className=" border w-full py-2"
            onClick={() => setopen(false)}
          >
            <div className="relative">
              <span className="bg-amber-600 rounded-full w-5 h-5 text-center pt-[3px] absolute -top-2 -right-2 text-[10px]">
                {getTotalCartItems()}
              </span>
              <Link to={`/Cart`}>
                <FontAwesomeIcon icon={faCartShopping} className="text-2xl" />
              </Link>
            </div>
          </button>
        </div>
      </div>
    </>
  );
};
