import React, { useContext } from "react";
import { FavoritesContext } from "./favoriteContext";
const FavoriteItems = () => {
  const { alldata, FavoritesItems, removeFromFavorite } =
    useContext(FavoritesContext);

  if (!alldata || alldata.length === 0) {
    return <p>Loading products...</p>;
  }

  return (
    <div className="bg-amber-950 w-full min-h-screen mt-0 p-[100px] max-md:p-5">
      <div className="cartitems">
        <div className="cartitems-format-main max-lg:gap-[15px]! max-lg:grid-cols-3!">
          <p>Products</p>
          <p>Title</p>
          <p>price</p>
          <p>Remove</p>
        </div>
        <hr />
        {alldata.map((e) =>
          FavoritesItems[e.id] > 0 ? (
            <div key={e.id}>
              <div className="cartitems-format max-lg:gap-[50px]! max-lg:grid-cols-3!">
                <img
                  src={e.image}
                  alt={e.name}
                  className="carticon-product-icon min-w-[50px]"
                />
                <p>{e.name}</p>
                <p>${e.price}</p>

                <button
                  className="cartitems-remove-icon"
                  src=""
                  onClick={() => removeFromFavorite(e.id)}
                  alt="Remove"
                >
                  remove
                </button>
              </div>
              <hr />
            </div>
          ) : null
        )}
      </div>
    </div>
  );
};

export default FavoriteItems;
