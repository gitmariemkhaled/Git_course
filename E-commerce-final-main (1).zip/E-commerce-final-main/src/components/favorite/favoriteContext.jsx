import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

export const FavoritesContext = createContext(null);

const FavoritesContextProvider = (props) => {
  const [alldata, setAlldata] = useState([]);
  const [FavoritesItems, setFavoritesItems] = useState({});
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("http://localhost:3000/products");
        setAlldata(response.data);
      } catch (error) {
        console.log("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    if (alldata.length > 0) {
      const defaultFavorites = {};
      alldata.forEach((product) => {
        defaultFavorites[product.id] = 0;
      });
      setFavoritesItems(defaultFavorites);
    }
  }, [alldata]);

  const addToFavorite = (itemId) => {
    setFavoritesItems((prev) => {
      if (prev[itemId]) return prev; 
      return { ...prev, [itemId]: true };
    });
  };

  const removeFromFavorite = (itemId) => {
    setFavoritesItems((prev) => {
      const newFavorites = { ...prev };
      delete newFavorites[itemId]; 
      return newFavorites;
    });
  };

  const getTotalFavoriteItems = () => {
    let totalItem = 0;
    for (const item in FavoritesItems) {
      if (FavoritesItems[item] > 0) {
        totalItem += FavoritesItems[item];
      }
    }
    return totalItem;
  };
  const contextValue = {
    getTotalFavoriteItems,
    alldata,
    FavoritesItems,
    addToFavorite,
    removeFromFavorite,
  };

  return (
    <FavoritesContext.Provider value={contextValue}>
      {props.children}
    </FavoritesContext.Provider>
  );
};

export default FavoritesContextProvider;
