import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import { useCallback, useEffect, useState, useContext } from "react";
import { ShopContext } from "../cart/shopContext";
import { FavoritesContext } from "../favorite/favoriteContext";
export const Products = () => {
  const { addToCart } = useContext(ShopContext);
  const { addToFavorite } = useContext(FavoritesContext);
  const [alldata, setalldata] = useState();
  const [searchTerm, setSearchTerm] = useState("the lost world");
  const [num, setnum] = useState(20);
  const [quantity, setQuantity] = useState(1);
  const [favoriteitem, setfavoriteitem] = useState(new Set());
  const handleAddToFavorite = (productId) => {
    setfavoriteitem((prev) => {
      if (prev.has(productId)) {
        return prev;
      }

      const newFavorites = new Set(prev);
      newFavorites.add(productId);
      addToFavorite(productId);
      return newFavorites;
    });
  };
  const handleclick = () => {
    setnum((prevnum) => prevnum + 10);
  };

  let fetchprodects = useCallback(async () => {
    try {
      const response = (
        await axios.get("http://localhost:3000/products")
      ).data.slice(0, num);
      setalldata(response);
      console.log(alldata);
    } catch (error) {
      console.log(error);
    }
  }, [searchTerm, num]);
  useEffect(() => {
    fetchprodects();
  }, [fetchprodects, searchTerm]);

  return (
    <>
      <section className="text-center min-h-screen p-10 py-30 bg-black/50 border-t">
        <h1 className="text-[size:clamp(1.7rem,10vw,3.5rem)] mb-10 font-bold font-serif uppercase">
          All products
        </h1>
        <div className="grid grid-cols-2 max-[400px]:grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-5 container max-w-7xl m-auto">
          {alldata && alldata.length > 0 ? (
            alldata.map((item) => (
              <div className="card hover:drop-shadow-2xl group transition-all px-1">
                <div className=" rounded-sm">
                  <div className="relative">
                    <div
                      className={`absolute opacity-0 group-hover:opacity-100 top-3 left-3 ${
                        favoriteitem.has(item.id) ? "opacity-100!" : ""
                      }`}
                    >
                      <button
                        onClick={() => handleAddToFavorite(item.id)}
                        className={`border border-black p-2 flex items-center justify-center rounded-lg shadow-lg shadow-amber-200 hover:bg-amber-200 ${
                          favoriteitem.has(item.id) ? "bg-amber-200" : ""
                        }`}
                      >
                        <FontAwesomeIcon
                          icon={faHeart}
                          className={`text-2xl ${
                            favoriteitem.has(item.id)
                              ? "text-red-600"
                              : "text-amber-600"
                          }`}
                        />
                      </button>
                    </div>
                    <Link to={`/Productdetils/${item.id}`}>
                      <img
                        className="rounded-b-sm w-full h-[300px] max-sm:h-[200px]"
                        src={
                          item.image && item.image !== undefined
                            ? `${item.image}`
                            : `./src/images/noimage.jpg`
                        }
                        alt=""
                      />
                    </Link>
                  </div>
                  <div className="p-2 h-[135px] max-sm:h-[120px] flex flex-col justify-around">
                    <h4 className="text-start text-orange-400 text-[size:clamp(12px,1vw,18px)]">
                      {item.name}
                    </h4>

                    <h4 className="text-start text-[size:clamp(12px,1vw,18px)]">
                      {item.price}
                    </h4>
                  </div>
                </div>
                <div className="uppercase border mt-2.5 rounded-sm max-md:text-lg opacity-0 group-hover:opacity-100 hover:bg-orange-400 flex">
                  <button
                    className="w-full border h-full cursor-pointer p-3"
                    onClick={() => addToCart(item.id, quantity)}
                  >
                    add to cart
                  </button>
                  <input
                    className="text-white p-2"
                    type="number"
                    id="quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    name="quantity"
                    min="1"
                    max="5"
                  />
                </div>
              </div>
            ))
          ) : (
            <div
              role="status"
              className="col-span-full flex items-center justify-center gap-x-1.5"
            >
              <div className="max-w-36">
                <svg
                  aria-hidden="true"
                  class="w-6 h-6 text-gray-200 animate-spin dark:text-gray-600 fill-amber-700"
                  viewBox="0 0 100 101"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                    fill="currentColor"
                  />
                  <path
                    d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                    fill="currentFill"
                  />
                </svg>
              </div>
              <h1 className="uppercase text-2xl">loding...</h1>
            </div>
          )}
        </div>

        <div className={`${alldata && alldata.length > 0 ? "mt-10 opacity-100" : "opacity-0"}`}>
          <h1 className="uppercase">
            <button
              onClick={handleclick}
              className="border p-3 rounded-lg text-2xl hover:bg-amber-950 cursor-pointer"
            >
              show more
            </button>
          </h1>
        </div>
      </section>
    </>
  );
};
