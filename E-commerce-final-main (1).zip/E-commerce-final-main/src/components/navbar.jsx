import { Link } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import { Mobilenav } from "./mobilenav";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { faBarsStaggered } from "@fortawesome/free-solid-svg-icons";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import { faCartShopping } from "@fortawesome/free-solid-svg-icons";
import { ShopContext } from "./cart/shopContext";
import { FavoritesContext } from "./favorite/favoriteContext";
export const Navbar = () => {
  const [open, setopen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { getTotalCartItems } = useContext(ShopContext);
  const { getTotalFavoriteItems } = useContext(FavoritesContext);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  let links = [
    { name: "Home", link: "/" },
    { name: "Products", link: "/Products" },
  ];
  return (
    <>
      <div
        className={`fixed top-0 h-16 w-full z-40 border-b border-white/50 shadow-lg ${
          scrolled ? "bg-amber-900" : "backdrop-blur-3xl"
        }`}
      >
        <div className="container mx-auto h-16 flex items-center justify-between px-4 max-w-5xl">
          <div className="flex items-center justify-start h-16">
            <Link
              to="/"
              className="text-4xl uppercase p-1 font-bold [text-shadow:_0_3px_4px_white]"
            >
              logo
            </Link>
          </div>
          <div className="flex-2 hidden md:block">
            <form action="#">
              <label htmlFor="search" className="flex flex-row px-5">
                <FontAwesomeIcon />
                <FontAwesomeIcon
                  icon={faMagnifyingGlass}
                  className="text-lg border p-3 rounded-l-2xl"
                />

                <input
                  id="search"
                  type="search"
                  className="border w-full text-white  p-2 rounded-r-2xl outline-0"
                  autoComplete="off"
                />
              </label>
            </form>
          </div>
          <div className="flex gap-6 items-center justify-end w-fit">
            <ul className="hidden gap-4 md:flex cursor-pointer">
              {links.map((item) => (
                <li className="hover:underline hover:text-amber-600 underline-offset-4">
                  <Link to={item.link}>{item.name}</Link>
                </li>
              ))}
            </ul>
            <div className="hidden md:flex">
              <div className="relative">
                <span className="bg-amber-600 rounded-full w-5 h-5 text-center pt-[3px] absolute -top-2 -right-3 text-[10px]">
                  {getTotalFavoriteItems()}
                </span>
                <Link to={`/Favorite`}>
                  <FontAwesomeIcon icon={faHeart} className="text-2xl" />
                </Link>
              </div>
            </div>
            <div className="hidden md:flex">
              <div className="relative">
                <span className="bg-amber-600 rounded-full w-5 h-5 text-center pt-[3px] absolute -top-2 -right-2 text-[10px]">
                  {getTotalCartItems()}
                </span>
                <Link to={`/Cart`}>
                  <FontAwesomeIcon icon={faCartShopping} className="text-2xl" />
                </Link>
              </div>
            </div>
            <div
              className="w-7 h-5 cursor-pointer md:hidden z-40 flex items-center"
              onClick={() => setopen((open) => !open)}
            >
              <FontAwesomeIcon icon={faBarsStaggered} className="text-2xl" />
            </div>
          </div>
        </div>
      </div>
      <Mobilenav open={open} setopen={setopen} links={links} />
    </>
  );
};
