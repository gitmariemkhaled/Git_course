import { useEffect } from "react";

export const LoadingScreen = ({onComplete}) => {
  useEffect(() => {
    setTimeout(() => {
      onComplete();
    }, 500);
  }, [onComplete]);
  return (
    <>
      <div className="fixed w-screen h-screen bg-black z-50 flex flex-col items-center justify-center">
        <h1 className="uppercase text-5xl text-black [text-shadow:_0px_1px_3px_white] animate-pulse">
          loadind...
        </h1>
      </div>
    </>
  );
};
