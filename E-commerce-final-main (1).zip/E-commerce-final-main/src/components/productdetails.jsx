import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import { ShopContext } from "./cart/shopContext";
import { FavoritesContext } from "./favorite/favoriteContext";
export const Productdetils = () => {
  const { addToCart } = useContext(ShopContext);
  const [pro, setpro] = useState();
  const [quantity, setQuantity] = useState(1);
  const { addToFavorite } = useContext(FavoritesContext);
  const [favoriteitem, setfavoriteitem] = useState(new Set());
  const handleAddToFavorite = (productId) => {
    setfavoriteitem((prev) => {
      if (prev.has(productId)) {
        return prev;
      }

      const newFavorites = new Set(prev);
      newFavorites.add(productId);
      addToFavorite(productId);
      return newFavorites;
    });
  };
  let id = useParams().id;
  useEffect(() => {
    let fetchproduct = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3000/products/${id}`
        );
        response ? setpro(response.data) : console.log("error");
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchproduct();
    console.log(pro);
  }, [id]);

  return (
    <>
      {pro ? (
        <div className="w-full min-h-screen bg-gray-200 pt-16">
          <h1 className="text-amber-800 font-bold text-center pt-7 max-w-2xl m-auto text-2xl px-10">
            {pro.name}
          </h1>
          ;
          <div className="grid max-[600px]:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 container max-w-7xl m-auto p-10">
            <div className="p-5  shadow-2xl shadow-amber-950 bg-white text-black rounded-2xl  flex items-center justify-center">
              <img className="w-full" src={pro.image} alt="" />
            </div>
            <div className=" shadow-2xl shadow-amber-950 bg-white text-black rounded-2xl p-5 flex flex-col justify-evenly px-10">
              <h1 className="text-center text-2xl m-3 uppercase font-bold">
                product details
              </h1>
              <h1 className="text-amber-800 font-bold my-5">{pro.name}</h1>
              <h2>{pro.details.description}</h2>
              <div className="flex items-center justify-around my-5">
                <h2 className="text-white px-3 py-1.5 rounded shadow-2xs shadow-amber-300 bg-amber-500">
                  {pro.price}
                </h2>
                <h2 className="text-white px-3 py-1.5 rounded shadow-2xs shadow-amber-300 bg-amber-500">
                  {pro.details.rating}
                </h2>
              </div>
            </div>

            <div className=" shadow-2xl shadow-amber-950 bg-white text-black rounded-2xl p-5">
              <div className=" mt-2.5 rounded-sm max-md:text-lg bg-orange-400 flex">
                <button
                  className="w-full h-full cursor-pointer p-3 uppercase font-bold text-white"
                  onClick={() => addToCart(pro.id, quantity)}
                >
                  add to cart
                </button>
                <input
                  className="text-white p-2"
                  type="number"
                  id="quantity"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  name="quantity"
                  min="1"
                  max="5"
                />
              </div>
              <div className="mt-2.5 rounded-sm max-md:text-lg bg-orange-400 flex">
                <button
                  onClick={() => handleAddToFavorite(pro.id)}
                  className={`p-2 flex items-center justify-around font-bold text-white uppercase rounded-sm w-full shadow-lg shadow-amber-200 ${
                    favoriteitem.has(pro.id) ? "bg-orange-400" : ""
                  }`}
                >
                  add to favorite
                  <FontAwesomeIcon
                    icon={faHeart}
                    className={`text-2xl ${
                      favoriteitem.has(pro.id)
                        ? "text-red-600"
                        : "text-amber-600"
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <p>data is loding...</p>
      )}
    </>
  );
};
