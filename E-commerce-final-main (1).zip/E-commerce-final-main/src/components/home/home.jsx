import { Allprodects } from "./allprodects";
import { Footer } from "./footer";
import { Landing } from "./landing";
import { Section1 } from "./section1";
export const Home = () => {
  return (
    <>
      <Landing />
      <Section1 />
      <Allprodects />
      <Footer />
    </>
  );
};
