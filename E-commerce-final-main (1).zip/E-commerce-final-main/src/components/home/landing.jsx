import { motion } from "framer-motion";
export const Landing = () => {
  return (
    <>
      <div className="bg-[url(/images/landingbg1.png)] bg-[size:100vw_100vh]  bg-no-repeat max-w-full">
        <div className="conainer min-h-[95vh] m-auto p-0 w-full">
          <div className="w-full min-h-[95vh] backdrop-blur-xs relative backdrop-brightness-50">
            <motion.img
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.5 }}
              className="max-w-sm max-xl:hidden absolute bottom-0 left-0 md:left-10"
              src="./images/landing.png"
              alt=""
            />
            <motion.img
              initial={{ opacity: 0, y: -50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="absolute max-xl:hidden top-10 right-0 max-lg:w-screen max-lg:h-screen lg:max-w-lg"
              src="./images/landing1.png"
              alt=""
            />
            <motion.div
              initial={{ y: -100, scale: 0.3, opacity: 0 }}
              animate={{ y: 0, scale: 1, opacity: 1 }}
              transition={{ duration: 1.5, type: "spring", stiffness: 120 }}
              className="min-h-[95vh] flex items-center justify-center"
            >
              <div className="p-5 md:px-10 flex justify-center items-center flex-col uppercase gap-y-3 z-40 max-xl:min-h-[95vh] max-xl:min-w-screen">
                <h1 className="text-center font-semibold text-[size:clamp(2.5rem,10vw,3.5rem)] leading-[1.2] [text-shadow:0px_0px_10px_black] max-w-2xl">
                  unfold the joy of shopping
                  <span className="[text-shadow:0px_0px_10px_gold]">✨</span>
                </h1>
                <hr className="w-70 md:w-100" />
                <p className="max-w-lg text-white/50 text-[16px] text-center z-40 font-sans">
                  Our a wide range of high-quality casual wear, formal
                  attire,ensuring that every customer finds the perfect style to
                  match their, to seamless and enjoyable shopping experience
                  from the comfort of your home.
                </p>
                <button class="relative inline-flex items-center justify-center p-0.5 mb-2 me-2 overflow-hidden text-sm font-medium text-black rounded-lg group bg-gradient-to-br from-red-200 via-red-300 to-yellow-200 group-hover:from-red-200 group-hover:via-red-300 group-hover:to-yellow-200 dark:hover:text-gray-900 focus:ring-4 focus:outline-none focus:ring-red-100 dark:focus:ring-red-400">
                  <span class="relative uppercase px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-yellow-200 rounded-md group-hover:bg-transparent group-hover:dark:bg-transparent font-semibold">
                    let's go
                  </span>
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};
