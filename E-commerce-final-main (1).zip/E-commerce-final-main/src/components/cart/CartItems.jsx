import React, { useContext } from "react";
import "./CartItems.css";
import { ShopContext } from "./shopContext";
const CartItems = () => {
  const { getTotalCartAmount, alldata, cartItems, removeFromCart } =
    useContext(ShopContext);

  if (!alldata || alldata.length === 0) {
    return <p>Loading products...</p>;
  }

  return (
    <div className="bg-amber-950 w-full min-h-screen mt-0 p-[100px] max-md:p-5">
      <div className="cartitems">
        <div className="cartitems-format-main max-lg:gap-[15px]! max-lg:grid-cols-3!">
          <p>Products</p>
          <p>Title</p>
          <p>Price</p>
          <p>Quantity</p>
          <p>Total</p>
          <p>Remove</p>
        </div>
        <hr />
        {alldata.map((e) =>
          cartItems[e.id] > 0 ? (
            <div key={e.id}>
              <div className="cartitems-format max-lg:gap-[50px]! max-lg:grid-cols-3!">
                <img
                  src={e.image}
                  alt={e.name}
                  className="carticon-product-icon min-w-[50px]"
                />
                <p>{e.name}</p>
                <p>${e.price}</p>
                <button className="cartitems-quantity">
                  {cartItems[e.id]}
                </button>
                <p>${e.price.slice(4).replace(",", "") * cartItems[e.id]}</p>
                <button
                  className="cartitems-remove-icon"
                  src=""
                  onClick={() => removeFromCart(e.id)}
                  alt="Remove"
                >
                  remove
                </button>
              </div>
              <hr />
            </div>
          ) : null
        )}
        <div className="cartitems-down">
          <div className="cartitems-total max-md:mr-0!">
            <h1>Cart Totals</h1>
            <div>
              <div className="cartitems-total-item">
                <p>Subtotal</p>
                <p>${getTotalCartAmount()}</p>
              </div>
              <hr />
              <div className="cartitems-total-item">
                <p>Shipping Fee</p>
                <p>Free</p>
              </div>
              <hr />
              <div className="cartitems-total-item">
                <h3>Total</h3>
                <h3>${getTotalCartAmount()}</h3>
              </div>
            </div>
            <button>Proceed to Checkout</button>
          </div>
          <div className="cartitems-promocode  max-md:mr-0!">
            <p>If you have a promo code, enter it here:</p>
            <div className="cartitems-promobox max-md:w-[300px]!">
              <input
                className="max-md:w-[300px]!"
                type="text"
                placeholder="Promo Code"
              />
              <button>Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItems;
