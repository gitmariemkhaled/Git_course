import "./App.css";
import { LoadingScreen } from "./components/loadingscreen";
import { useState } from "react";
import { Navbar } from "./components/navbar";
import { Home } from "./components/home/home";
import { Products } from "./components/sections/products";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Productdetils } from "./components/productdetails";
import ShopContextProvider from "./components/cart/shopContext";
import FavoritesContextProvider from "./components/favorite/favoriteContext";
import CartItems from "./components/cart/CartItems";
import FavoriteItems from "./components/favorite/favoriteItems";

function App() {
  const [loading, setloading] = useState(false);
  return (
    <>
      {!loading && (
        <LoadingScreen
          onComplete={() => {
            setloading(true);
          }}
        />
      )}
      <ShopContextProvider>
        <FavoritesContextProvider>
          <BrowserRouter>
            <div
              className={`w-full pt-8 ${loading ? "opacity-100" : "opacity-0"}`}
            >
              <Navbar />
              <Routes>
                <Route path="/Productdetils/:id" element={<Productdetils />} />
                <Route index element={<Home />} />
                <Route path="/Products" element={<Products />} />
                <Route path="/Cart" element={<CartItems />} />
                <Route path="/Favorite" element={<FavoriteItems />} />
              </Routes>
            </div>
          </BrowserRouter>
        </FavoritesContextProvider>
      </ShopContextProvider>
    </>
  );
}

export default App;
